# Red Panda Onboarding Starter Pack

This pack is an original red-panda visual system for a food/wellness onboarding flow. It is organized around five moments: welcome and goals, mascot discovery, habit and body setup, plan reveal, and retention/conversion.

## Included

- 10 transparent PNG mascot poses for compositing in app screens.
- 10 small SVG UI icons for goals, reminders, personality selection, and BMI feedback.
- A silent 5-second portrait MP4 welcome animation.
- `manifest.json` mapping assets to onboarding stages.

## Suggested usage

Use `wink_headshot.png` on the opening value proposition; `bamboo_peek.png` and `happy_pounce.png` for the mascot reveal; `heart_eyes.png` during naming; the personality icons during tone selection; `thinking_pose.png` and `sleeping_pose.png` for habit questions; `cheer_pose.png` and `scroll_reader.png` for plan generation; and `gift_box_pop.png` / `peekaboo_bottom.png` for offers and widgets.

All mascot PNGs are 1920×1920 with transparent backgrounds. The animation is 480p portrait, silent, and 5 seconds long.
